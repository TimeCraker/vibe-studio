# workspace-tools

工作区通用工具，目前提供文档生成、变更影响定位、提交检查与本地知识检索。内容制作技能由 vibe-studio 管理。

## 文档维护

在 workspace 根目录运行：

```powershell
node config/workspace-tools/scripts/setup-skills.mjs
node config/workspace-tools/scripts/docs.mjs maintain --repo vibe-studio
node config/workspace-tools/scripts/docs.mjs search --workspace . --query "网页采集"
```

跨仓库调用时使用工具绝对路径，`--repo` 指向目标仓库。技能说明见 [doc-maintainer](skills/doc-maintainer/SKILL.md)。工作区 `.agents/skills/doc-maintainer` 和 `.claude/skills/doc-maintainer` 都链接到这一份正本，不在内容项目再安装副本。

maintain 生成确定事实并列出候选说明，当前 Agent 阅读 diff 后修订现有段落；工具本身不调用模型、网络或替人审稿。不要求逐次填表或创建报告。具体边界见[文档维护说明](docs/documentation.md)。

## 维护与发布

Node >=22，无运行时第三方依赖。运行 `npm test` 验证工具，然后运行 `node scripts/docs.mjs check` 和 `git diff --check`。

独立项目若要在其他机器或 CI 使用，依赖固定版本发布包。vibe-studio 的 `scripts/docs.mjs` 是调用入口，依赖其 `tools/` 内的 npm 包，通过 `npm ci` 离线安装，无需这台电脑的 workspace 路径。

修改工具并发布时递增 package.json 版本，通过测试后在此目录执行 `npm pack --pack-destination <使用方的tools绝对路径>`，再在使用方执行 `npm install --save-dev ./tools/<新包名>.tgz --ignore-scripts --no-audit --no-fund`，删除已经不被 package-lock.json 引用的旧发布包。检查使用方的文档和测试后分别提交。发布包是源码生成的版本依赖，只在这里修改源码，不手改包或 node_modules。

本仓库由 vibe-studio 的文档工具历史迁入（源版本 8f9cd31）。本地钩子的旧 ownership 标记保留兼容，安装、更新和移除仍校验内容哈希；标记名称不表示工具仍归内容项目。
